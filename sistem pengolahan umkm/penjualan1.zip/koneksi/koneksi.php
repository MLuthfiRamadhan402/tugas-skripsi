<?php 
session_start();

$namahost="localhost";
$user="root";
$password="";
$database="kasir";

$koneksi= mysqli_connect("$namahost","$user","$password","$database");

 ?>


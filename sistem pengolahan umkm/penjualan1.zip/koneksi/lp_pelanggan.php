<?php 

$namahost="localhost";
$user="root";
$password="";
$database="pelanggan";

$con= mysqli_connect("$namahost","$user","$password","$database");



 ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Nama Pelanggan</title>
</head>
<body>
	<div style="margin: auto; width: 410px;">
	<h1>Nama Pelanggan</h1>
			<div style="border: 1px solid black; width: 400px; padding: 9px; ">
				<form action="cek.php" method="get">
					<table>
						<tr>
							<td>Nama Pelanggan :</td>
							<td><input type="text" name="namapelanggan" autofocus autocomplete="off"></td>
						</tr>
						<tr>
							<td></td>
							<td><button name="pesan">Pesan</button></td>
						</tr>
					</table>
				</form>
			</div>
			</div>
</body>
</html>
<?php

include '../koneksi/koneksi.php';
include '../koneksi/lp_pelanggan.php';
$menu = $_GET['menu'];

if ($menu === $_GET['menu']) {
	$tp = mysqli_query($con, "SELECT * FROM pesan WHERE menu='$menu'  ");
	$tp=mysqli_fetch_assoc($tp);
	$satuan = $tp['satuan'];

// memnampilkan pehitungan sementara untuk di input ke update
		$aa = mysqli_query($koneksi, "SELECT * FROM stok WHERE menu='$menu'");
		$aa = mysqli_fetch_assoc($aa);
		$total = $aa['satuan'] + $satuan;

		// update data satuan di databases tabel stok
		mysqli_query($koneksi, "UPDATE stok SET satuan='$total' 
		WHERE menu='$menu'");

	mysqli_query($con, "DELETE FROM pesan WHERE menu='$menu' ");





	header('location:index.php');
}

<?php 

include 'koneksi/koneksi.php';

if (isset($_POST['submit'])){

	$nama= $_POST['nama'];
	$password= $_POST['password'];

	$aa=mysqli_query($koneksi,"SELECT * FROM user WHERE username='$nama' ");
	$aa= mysqli_fetch_assoc($aa);

	if($nama === $aa['username']){

			if($password === $aa['password']){

				$_SESSION['login'] = true;
				header('location:index.php');

			}else{
				echo "<script>

		alert('Password Anda Salah');
		window.location.href('tambah_makan.php');

	</script>";
			}
	}else{
		echo "<script>

		alert('Username Anda Salah');
		window.location.href('tambah_makan.php');

	</script>";
	}

}

	// login ke tampilan utama
if (!isset($_SESSION['login'])){

}else{
	header('location:index.php');
}


 ?>


<!DOCTYPE html>
<html>

<head>
	<title>Tamabah Menu Makanan</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
	<center>
		<form action="" method="post" enctype="multipart/form-data">

			<fieldset>

				<legend align=cemter;><b>Login</b></legend>
				<div class="label">

					<label for="nama">Username :
						<input type="text" name="nama" id="nama" required>
					</label>
				</div>
				<br>
				<div>
					<label for="password">Password:
						<input type="password" name="password" id="password" required>
					</label>
				</div>
				<br>
				
				<button type="submit" name="submit">Login</button>



			</fieldset>

		</form>
	</center>
</body>

</html>
